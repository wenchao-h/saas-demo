const configs = require('../config.js');
const { RUN_MODE } = require('../config.js');

const bk = {
    globalData: {
        debug: configs.DEBUG,
        smartGateSession_Expire_Time: 600000,
        smartGateSession: null,
        smartGatePrefixed: configs.RIO_URL,
        smartGateApp: configs.RIO_APP,
        avatarUrl: '',
        wxkey: '',
        RUN_MODE: configs.RUN_MODE
    },

    //登陆鉴权
    authorize: function (cb) {
        const that = this;
        let _identity = wx.getStorageSync('__identity');
        if (!_identity) {
            _identity = "{}"
        }

        // 过设置的过期时间，则重新读取wx_key
        if (Date.now() < JSON.parse(_identity).expire_time) {
            typeof cb == "function" && cb(JSON.parse(_identity));
        } else {
            wx.login({
                success: function (res) {
                },
                fail: function () {
                    // fail
                    console.log(`fail:${res}`);
                },
                complete: function () {
                    // complete
                }
            });
        }
    },

    //请求数据
    request: function (param) {
        const that = this;
        param.url = that.getBkUrl(param.url);
        wx.request(param)
    },

    //获取本地Django后台的URL
    getBkUrl: function (url) {
        return bk.globalData.smartGatePrefixed + configs.BK_PATH + url
    }
};

module.exports = bk

