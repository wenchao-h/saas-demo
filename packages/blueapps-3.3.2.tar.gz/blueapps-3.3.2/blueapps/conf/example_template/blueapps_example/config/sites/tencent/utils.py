# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from blueapps_example.config import settings
from django.utils.translation import gettext_lazy as _

from blueapps.core.exceptions import ApiResultError
from blueapps.utils import client, get_client_by_user


def get_app_by_user_role(request):
    """
    外部版调用cc中的get_application.
    封装返回数据逻辑是:遍历data中的每一个application,
    查看application的ver_setting中设置的几个user_role字段中是否存在当前登录用户名对应的RTX
    有则将application及user_role加入返回值
    @param username: QQ号
    @type username: unicode
    @return:
    @rtype: list
    """
    data_json = []

    rtx_kwargs = {"uin_list": request.user.username}
    # 由于get_application调用需要的username需要的是RTX,通过get_rtx_by_uin从QQ号获取RTX
    rtx_result = client.auth.get_rtx_by_uin(rtx_kwargs)
    if rtx_result["result"]:
        rtx_data = rtx_result["data"]
        username = rtx_data[0]["rtx"]
    else:
        raise ApiResultError(_(u"esb调用get_rtx_by_uin结果为False"))

    kwargs = {}
    application_info_result = client.cc.get_application(kwargs)
    # CC_ROLES 为常量（常量英文名，常量中文名）
    # 由于get_application()获取到的数据是根据app分隔,为了构造根据user_role分隔,需要先遍历一遍data,再加入result_json
    user_role_dict = {_user_role[0]: list() for _user_role in settings.CC_ROLES}
    if application_info_result["result"]:
        data = application_info_result["data"]
        # 遍历所有application
        for _application_info in data:
            # 遍历所有user_role
            for _user_role in settings.CC_ROLES:
                # 判断当前applicaiton的当前user_role字段中是否包含当前username
                if username in _application_info[_user_role[0]]:
                    user_role_dict[_user_role[0]].append(
                        {
                            "ApplicationName": _application_info[
                                settings.CC_APPLICATIONNAME
                            ],
                            "UserRoleName": _user_role[1],
                            "ApplicationID": _application_info["ApplicationID"],
                        }
                    )
        # CC_ROLES 为常量（常量英文名，常量中文名）
        # 将根据user_role分隔的application的多个list连接成一个返回数据list
        for _user_role in settings.CC_ROLES:
            data_json.extend(user_role_dict[_user_role[0]])
    return data_json


def send_msg(username, title, message):
    """
    外部版调用tof中send_mail
    @param username: QQ号
    @param message: 发送的标题
    @type message: unicode
    @type username: unicode
    @param message: 发送的信息
    @type message: unicode
    @return:
    @rtype: dict
    """
    # 不重新引用线上会报错,暂时不知道问题在哪
    client = get_client_by_user(username)
    kwargs = {
        "sender": username,
        "receiver": username,
        "title": title,
        "content": message,
    }
    result = client.tof.send_mail(kwargs)
    return result
