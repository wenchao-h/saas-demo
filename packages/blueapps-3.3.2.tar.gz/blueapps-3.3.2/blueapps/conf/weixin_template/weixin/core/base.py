# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

import abc
import base64
import hashlib
import hmac
import logging
import random
import string
import sys
import time

import requests
import six

import settings

_ver = sys.version_info
#: Python 2.x?
is_py2 = _ver[0] == 2
#: Python 3.x?
is_py3 = _ver[0] == 3

logger = logging.getLogger("blueapps")


class API(six.with_metaclass(abc.ABCMeta)):
    def __init__(self):
        try:
            cur_module = __import__(
                "weixin.core", globals(), {}, ["settings_weixin_api"]
            )
            self._config = cur_module.settings_weixin_api
        except Exception as err:  # pylint: disable=broad-except
            self._config = None
            logger.error(u"加载settings_weixin_api 配置文件出错：%s" % err)
        self.app_code = settings.APP_CODE
        self.secret_key = settings.SECRET_KEY
        self.timeout = 10
        self.ssl_verify = False

    def http_get(self, http_url, **kwargs):
        """
        http 请求GET方法
        """
        try:
            resp = requests.get(
                http_url, params=kwargs, timeout=self.timeout, verify=self.ssl_verify
            )
            resp = resp.json()
            return resp
        except Exception as error:  # pylint: disable=broad-except
            logger.error("requests get url:{} error: {}".format(http_url, error))
            return {}

    def http_post(self, http_url, **kwargs):
        """
        http 请求POST方法
        """
        try:
            resp = requests.post(
                http_url, json=kwargs, timeout=self.timeout, verify=self.ssl_verify
            )
            resp = resp.json()
            return resp
        except Exception as error:  # pylint: disable=broad-except
            logger.error(
                "requests post url:{} kwargs: {} error {}".format(
                    http_url, kwargs, error
                )
            )
            return {}

    def nonce_str(self, length=15):
        """
        随机字符串
        """
        nonce = "".join(
            random.choice(string.ascii_letters + string.digits) for _ in range(length)
        )
        return nonce

    def nonce_num(self, upper_limit_length=6):
        """
        指定位数的随机数
        upper_limit_length: 上限位数
        """
        if 0 < upper_limit_length <= 1000:
            end_num = 10 ** (upper_limit_length + 1) - 1
            num = random.randint(1, end_num)
        else:
            num = 1
        return num

    def gen_signature(self, query_param, url_path, request_method):
        """
        生成签名
        """
        params = "&".join(
            ["{}={}".format(key, query_param[key]) for key in sorted(query_param)]
        )
        message = "{}{}?{}".format(request_method, url_path, params)
        if is_py2:
            digest_make = hmac.new(self.secret_key, message, hashlib.sha1).digest()
        elif is_py3:
            digest_make = hmac.new(
                bytes(self.secret_key, encoding="utf-8"),
                message.encode(encoding="utf-8"),
                hashlib.sha1,
            ).digest()
        else:
            digest_make = None
        _signature = base64.b64encode(digest_make)
        return _signature

    @property
    def timestamp(self):
        """
        时间戳
        """
        return int(time.time())
