// demo.js
const app = getApp()
Page({
    data: {
        useWxAuth: false,
        paperList: [],
        userInfo: {},
        isIphoneX: false,
        currentOpreator: '',
        categoryList: [],
        isShowCategoryList: false,
        displayType: '全部',
        showType: 'all',
        containerHeight: 200,
        page: 1,
        categoryId: 0,
        isLoading: false,
        total: {
            all: 0
        },
        hasNoMore: false,
        taskNum: 0
    },

    onShow: function () {
        const that = this
        this.setData({
            showType: 'all'
        })
        wx.getSystemInfo({
            success: res => {
                if (this.data.isIphoneX) {
                    wx.createSelectorQuery().selectAll('.header').boundingClientRect(function (rects) {
                        rects.forEach(function (rect) {
                            that.setData({
                                containerHeight: res.windowHeight - rect.bottom - 58 - 40
                            });
                        })
                    }).exec()
                } else {
                    wx.createSelectorQuery().selectAll('.header').boundingClientRect(function (rects) {
                        rects.forEach(function (rect) {
                            that.setData({
                                containerHeight: res.windowHeight - rect.bottom - 58
                            });
                        })
                    }).exec()
                }
            }
        })
    },

    onLoad: function (options) {
        const that = this
        that.setData({
            isIphoneX: app.globalData.isIphoneX ? app.globalData.isIphoneX : false,
            hasNoMore: false
        })
        this.getCategory()
        this.getLatestList()
        wx.getSetting({
            success(res) {
                // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                wx.getUserInfo({
                    success: function (res) {
                        that.setData({
                            userInfo: res.userInfo
                        })
                    },
                    fail: (err) => {
                        console.log(err)
                    }
                })
            }
        })
    },

    getCategory() {
        app.request({
            url: '/category/',
            success: res => {
                if (res.statusCode == 200 && res.data && res.data.result) {
                    let list = [{id:0, name: '全部'}].concat(res.data.data)
                    this.setData({
                      categoryList: list
                    })
                } else {
                    wx.showToast({
                        title: '系统错误',
                        icon: 'none',
                        mask: true
                    })
                }
            }
        })
    },

    getLatestList(event) {
        let more = event && event.currentTarget.dataset.more
        if (more) {
            this.setData({
                page: 1,
                isLoading: true,
            })
        } else {
            if (this.data.hasNoMore) return
        }
        // 页面显示
        const that = this;
        //位取最新发文
        wx.showLoading({
            title: '数据加载中'
        });
        app.request({
            url: `/?page=${this.data.page}&pageSize=10&category_id=${this.data.categoryId}`,
            success: function (res) {
                if (res.statusCode == 200 && res.data && res.data.result) {
                    const allCount = 'total.all'
                    that.setData({
                        taskNum: res.data.data.task_num,
                        [allCount]: res.data.data.total
                    })
                    if (more) {
                        that.setData({
                            paperList: []
                        })
                    }
                    that.setData({
                        paperList: that.data.paperList.concat(res.data.data.list),
                        showType: 'all',
                        displayType: '全部'
                    })
                    if (res.data.data.total > that.data.paperList.length) {
                        that.setData({
                            hasNoMore: false
                        })
                    } else {
                        that.setData({
                            hasNoMore: true
                        })
                    }
                } else {
                    wx.showToast({
                        title: '系统错误',
                        icon: 'none',
                        mask: true
                    })
                }
            },
            complete: () => {
                wx.hideLoading()
                this.setData({
                    isLoading: true
                })
            }
        })
    },

    searchScrollLower() {
      const that = this
      this.setData({
        page: that.data.page + 1
      })
      if (this.data.showType === 'all') {
        this.getLatestList()
      }
    },

    selectCategory(event) {
      const categoryId = event.currentTarget.dataset.type.id
      this.setData({
        page: 1,
        hasNoMore: false,
        isLoading: false,
        categoryId: categoryId,
        paperList: []
      })
      this.getLatestList()
    },

    showCategorySelect() {
      const that = this
      this.setData({
        isShowCategoryList: !that.data.isShowCategoryList
      })
    },

    getTag1(event) {
      this.setData({
        page: 1,
        hasNoMore: false,
        isLoading: false,
        categoryId: 0,
        paperList: []
      })
      this.getLatestList()
    },

    getTag2(event) {
      wx.showToast({
        title: '此功能尚未开放，请稍候',
        icon: 'none',
        mask: true
      })
    },

    getTag3(event) {
      wx.showToast({
        title: '此功能尚未开放，请稍候',
        icon: 'none',
        mask: true
      })
    },

    getTag4(event) {
      wx.redirectTo({
        url: '../no-permission/no-permission',
      })
    },

    getPaperDetail(event) {
      const id = event.currentTarget.dataset.id
      wx.navigateTo({
        url: `../detail/detail?id=${id}`
      })
    },
})
