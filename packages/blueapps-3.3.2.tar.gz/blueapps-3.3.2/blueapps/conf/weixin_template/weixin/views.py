# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

import logging

from django.http import JsonResponse
from django.shortcuts import render
from django.utils.translation import gettext_lazy as _
from weixin.core.api import WeiXinApi

from blueapps.utils import client

logger = logging.getLogger("app")


def index(request):
    """
    @summary: 业务数据页面
    """
    return render(request, "/weixin/index.mako", {})


def share_template(request):
    """
    微信js-sdk样例页面
    """
    ctx = {}
    js_sign = {}
    # 判断是否为微信端访问
    is_wechat = request.is_wechat()
    # 非微信端访问无法测试微信js-sdk相关功能
    if is_wechat:
        weixin_api = WeiXinApi()
        js_sign_result = weixin_api.get_js_sign(
            request.build_absolute_uri(), request.method
        )
        js_sign = js_sign_result.get("data")
    ctx = {"is_wechat": is_wechat, "js_sign": js_sign}
    return render(request, "/weixin/share_template.mako", ctx)


def get_biz_histogram_data(request):
    """
    @summary: 业务星级数据统计柱状图数据
    """
    try:
        username = request.user.username
        result = client.cc.get_app_list_by_name({"name": username})["data"]
        data_dict = {}
        data = {"categories": [], "data": []}
        for i in result:
            if i["BipGradeName"] not in data_dict:
                data_dict[i["BipGradeName"]] = 0
            data_dict[i["BipGradeName"]] += 1
        for k in data_dict:
            star = _(u"其他") if k == "" or k is None else k
            data["categories"].append(star)
            data["data"].append(data_dict[k])
    except Exception:  # pylint: disable=broad-except
        logger.exception(u"获取数据出错")
        data = {"categories": [], "data": []}
    return JsonResponse(data)


def get_biz_pie_data(request):
    """
    @summary: 业务星级数据统计饼图数据
    """
    try:
        username = request.user.username
        result = client.cc.get_app_list_by_name({"name": username})["data"]
        data_dict = {}
        data = {"categories": [], "data": []}
        for i in result:
            if i["BipGradeName"] not in data_dict:
                data_dict[i["BipGradeName"]] = 0
            data_dict[i["BipGradeName"]] += 1
        for k in data_dict:
            star = _(u"其他") if k == "" or k is None else k
            data["categories"].append(star)
            data["data"].append({"name": star, "value": data_dict[k]})
        if not data["categories"]:
            data = {
                "categories": [_(u"无业务")],
                "data": [{"name": _(u"无业务"), "value": 1}],
            }
    except Exception as err:
        logger.exception(u"获取数据出错: %s" % err)
        data = {"categories": [_(u"无业务")], "data": [{"name": _(u"无业务"), "value": 1}]}
    return JsonResponse(data)
