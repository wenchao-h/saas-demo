const fileManager = wx.getFileSystemManager();
let config;
try{
  fileManager.accessSync('./is_local')
  config = require('./config/dev.js');
}catch(e){
  config = require('./config/prod.js');
}
module.exports = {
  RIO_URL: config.RIO_URL,
  RIO_APP: "填写您在RIO申请的KEY",
  BK_PATH: "/wxapp",
  DEBUG: false,
  RUN_MODE: config.RUN_MODE,
}
