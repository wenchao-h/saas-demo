// 注意：dev.js文件只有在wechat/目录下添加is_local空文件后才能生效
module.exports = {
  RUN_MODE: "dev",
  RIO_URL: "本地django服务器地址"
}
