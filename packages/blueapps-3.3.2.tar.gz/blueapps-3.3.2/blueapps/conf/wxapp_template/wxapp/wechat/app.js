//app.js
/*
*  蓝鲸内部版小程序登录模块
*/
const fileManager = wx.getFileSystemManager();
let bk;
try{
  fileManager.accessSync('./is_local')
  bk = require('./auth/dev_auth.js');
}catch(e){
	bk = require('./auth/auth.js');
}
const configs = require('./config.js');

App({
	globalData: {
		debug: configs.DEBUG,
		isLogin: false,
		userInfo: {},
		staffInfo: {},
		isIphoneX: false
	},

	...bk,
	onLaunch: function () {
		const that = this;
		this.authorize(function(res) {
			that.isLogin = true
			that.globalData.userInfo = {
				uid: res.staffID,
				username: res.engName
			}
		})
	},

	onShow:function(){
		const that = this;
		wx.getSystemInfo({
			success: res=>{
				const modelmes = res.model;
				if (modelmes.search('iPhone X') !== -1) {
					that.globalData.isIphoneX = true
				}
			}
		})
	}
})
