# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from blueapps_example.config import settings

from blueapps.utils import client, get_client_by_user


def get_app_by_user_role(request):
    """
    内部版和混云版调用的是get_app_by_user_role.
    封装返回数据逻辑是:从data中找到ver_setting中设置的几个user_role字段对应的数据
    """
    data_json = []

    # 发送数据
    kwargs = {"user_role": ",".join(temp_tuple[0] for temp_tuple in settings.CC_ROLES)}
    user_info_result = client.cc.get_app_by_user_role(kwargs)

    if user_info_result["result"]:
        data = user_info_result["data"]
        # 循环封装字段 待优化，考虑缓存
        # CC_ROLES 为常量（常量英文名，常量中文名）
        for _, key in enumerate(settings.CC_ROLES):
            for result_data in data[key[0]]:
                result_data["ApplicationName"] = result_data[
                    settings.CC_APPLICATIONNAME
                ]
                result_data["UserRoleName"] = key[1]
                data_json.append(result_data)
    return data_json


def send_msg(username, title, message):
    """
    混云版版调用cmsi中send_mail
    @param username: RTX
    @type username: unicode
    @param message: 发送的标题
    @type message: unicode
    @param message: 发送的信息
    @type message: unicode
    @return:
    @rtype: dict
    """
    # 不重新引用线上会报错,暂时不知道问题在哪
    client = get_client_by_user(username)
    kwargs = {"receiver__uin": username, "title": title, "content": message}
    result = client.cmsi.send_mail(kwargs)
    return result
