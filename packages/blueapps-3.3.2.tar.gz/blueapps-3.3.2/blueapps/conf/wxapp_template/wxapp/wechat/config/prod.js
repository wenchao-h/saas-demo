module.exports = {
  RUN_MODE: "prod",
  RIO_URL: "填写RIO外网网址"
}
