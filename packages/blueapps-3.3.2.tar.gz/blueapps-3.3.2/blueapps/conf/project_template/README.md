[[toc]]

#一. 快速开始

 __Hello World! 使用开发框架创建您的第一个项目__


## 1. 创建应用

操作入口是 "蓝鲸|开发者中心-》应用开发-》创建应用"，填写应用 ID 和应用名称，点击"创建应用"。


## 2. 从 SVN 中签出（checkout）代码

应用创建完成后，点击页面上的"签出代码"，将应用的目录（开发框架已经初始化到您的代码仓库）checkout 到本地来以便您开发应用。您也可以通过入口“应用开发-》概览”签出代码。

__注意__：本地开发路径中请不要包含中文。


## 3. 开发第一个 hello world Django 应用

- 在 config/default.py 的 INSTALLED_APPS 中加入 'home_application' (默认已添加)。
- 在 urls.py 的 urlpatterns 加入 url(r'^', include('home_application.urls')) (默认已添加)。
- 在 home_application/views.py 加入：

```python
def hello(request):
    return HttpResponse('Hello World!')
```

- 修改 home_application/urls.py：

```python
from django.conf.urls import url
from home_application import views

urlpatterns = [
    url(r'^$', views.hello),
]
```


## 4. 提交代码到 SVN，部署到预发布环境

操作入口： "蓝鲸|开发者中心-》应用引擎-》部署管理"。
点击"部署至预发布环境"，等待部署成功，就可以通过页面上的"访问"链接看到 "Hello World!" 页面了。


## 5. 本地运行项目

如果需要本地运行项目，请按照蓝鲸官方文档《新手入门》配置开发环境，然后进行执行如下命令

```bash
python manage.py migrate
python manage.py runserver appdev.{PAAS_HOST}:8000
```

然后访问 http://appdev.{PAAS_HOST}:8000。


# 二. 使用文档


## 1. 目录结构说明

### 1.1 项目目录结构

```
- bin                           # 脚本命令
	- post_compile              # 部署前置命令，更多请查看蓝鲸官方文档《部署前置命令》
- config                        # 应用配置目录
	- __init__.py               # 应用 RUN_VER（ieod/clouds/qcloud）、APP_CODE 和 SECRET_KEY 等配置
	- dev.py                    # 本地开发配置（开发团队共享）
	- default.py                # 全局配置
	- prod.py                   # 生产环境配置
	- stag.py                   # 预发布环境配置
- home_application              # Django 模板应用样例
	- __init__.py
	- admin.py
	- urls.py
	- models.py
	- tests.py
	- views.py
	- templates                 # Django 模板
		- home_application
			- contact.html      # 联系我们页面
			- home.html         # 首页
- mako_templates                # mako 公共模板文件
	- base.mako                 # mako 模板基础文件，其他的页面可以从这里继承
- mako_application              # mako 模板应用样例
	- __init__.py
	- admin.py
	- urls.py
	- models.py
	- tests.py
	- views.py
	- mako_templates            # 模板
		- mako_application
			- contact.mako      # 联系我们页面
			- home.mako         # 首页
- static                        # 公共静态文件
	- js                        # 公共 js
		- csrftoken.js          # CSRFTOKEN
		- settings.js           # 异常处理
- templates                     # 公共模板文件
	- admin                     # admin模板文件
		- base_site.html
		- login.html
	- base.html                 # Django 模板基础文件，其他的页面可以从这里继承
- manage.py                     # Django 工程 manage
- Procfile                      # 应用进程管理文件，如果使用 Celery 需要修改
- requirements.txt              # 依赖的 python 包列表
- requirements_services.txt     # PaaS 增强服务依赖的 python 包列表
- settings.py				    # Django工程 settings
- urls.py                       # Django工程主路由 URL 配置
- wsgi.py                       # WSG I配置
```


### 1.2 常用配置说明

- App 基本信息
在 config/\__init\__.py 可以查看 App 基本信息，如 APP_CODE 和 SECRET_KEY 用于 App 认证，RUN_VER 是当前 App 运行的 PaaS 版本（ieod：内部版, clouds：混合云版，qcloud：腾讯云版等），请不要修改。

- App 运行环境
在 config/dev.py、config/stag.py、config/prod.py 中都有一个 RUN_MODE 的变量，用来标记 App 运营环境（DEVELOP：本地环境，STAGING：预发布环境，PRODUCT：正式环境），请不要修改。

- 日志级别和路径
开发框架默认配置的日志级别是 INFO，你可以在 config/default.py 修改 LOG_LEVEL 变量，会对所有运行环境生效，你也可以单独修改config/dev.py、config/stag.py、config/prod.py 文件，详情请参考“8. 日志使用”。
你不需要关心线上运行环境的日志路径，这些开发框架已经自动帮你配置了；本地的日志放在和项目根目录同一级的 logs 目录下，以 APP_CODE 命名的文件夹中，其中 {APP_CODE}-django.log 是应用日志，{APP_CODE}-celery.log 是 celery 日志，{APP_CODE}-component.log 是组件日志，{APP_CODE}-mysql.log 是数据库日志。

- 数据库配置
本地数据库配置请在 config/dev.py 修改 DATABASES 变量；多人合作开发建议在根目录下新建 local_settings.py 文件，并配置 DATABASES 变量，并且在版本控制中忽略 local_settings.py，这样的好处是防止多人合作开发时本地配置不一致导致代码冲突。
你不需要关心线上线上运行环境的数据库配置，不过你可以线上运行环境通过 django.settings.DATABASES 获取数据库配置。


## 2. 开发环境搭建（python）


### 2.1 安装 python（2.7 或 3.6）


### 2.2 安装 Mysql（5.5以上）


### 2.3 安装 setuptools、pip 和 blueapps

__注意__：安装 blueapps 需要使用蓝鲸 pypi 源，可以在 pip 配置文件中设置，也可以使用如下命令安装

```bash
pip install blueapps -i {PYPI} --trusted-host {PYPI_HOST}
```


### 2.4 安装本地开发工具

推荐使用 pycharm 进行代码开发，使用 TortoiseSVN 管理 SVN，使用 SourceTree 管理 GIT。


### 2.5 安装 celery（需要使用后台任务的项目）

安装 blueapps 时会自动安装 celery==3.1.25 和 django-celery==3.3.1。目前 celery 支持 redis、rabbitmq 作为任务的消息队列，推荐使用 redis。

- mac 系统 redis 使用指南：
安装指令 `brew install redis`；
启动指令 `redis-server`；
测试 redis 服务是否正常启动，`redis-cli` 尝试连接本地的 redis 服务。

- windows 系统 redis 使用指南
下载安装地址： https://github.com/MicrosoftArchive/redis/releases。
点击安装目录下的 redis-server.exe 启动 redis 服务。

- 配置项（在 config/dev.py 文件中修改消息队列配置）

```python
# Celery 消息队列设置 RabbitMQ
# BROKER_URL = 'amqp://guest:guest@localhost:5672//'

# Celery 消息队列设置 Redis
BROKER_URL = 'redis://localhost:6379/0'
```


### 2.6 配置 hosts

本地需要修改 hosts 文件，添加如下内容：

```
127.0.0.1 appdev.{PAAS_HOST}
```


### 2.7 配置本地数据库

首先在 MySQL 命令行下创建数据库：

```bash
CREATE DATABASE  `{APP_CODE}` default charset utf8 COLLATE utf8_general_ci; 
```

然后配置本地数据库账号密码，需要找到 config/dev.py 中的 DATABASES 配置项，修改 USER 和 PASSWORD。


### 2.8 初始化本地数据库

在项目根目录下执行如下命令初始化本地数据库：

```bash
python manage.py migrate
```

如果遇到错误，请先注释掉 config/default.py 的 INSTALLED_APPS 中的 APP 列表，执行命令后再去掉注释。


### 2.9 启动项目

在项目根目录下执行如下命令启动项目：

```bash
python manage.py runserver appdev.{PAAS_HOST}:8000
```

接着在浏览器访问 http://appdev.{PAAS_HOST}:8000 就可以访问到项目首页了。


## 3. 新建 application


### 3.1 在根目录下执行 bk-admin startapp yourappname


### 3.2 进入 yourappname 目录，新增 urls.py


### 3.3 编写逻辑代码和路由配置代码


### 3.4 把 yourappname 加入 config/default.py 的 INSTALLED_APPS 中


## 4. 定义 model


### 4.1 在新建的 application 中 models.py 定义model

官方文档： [Django Models](https://docs.djangoproject.com/en/1.11/topics/db/models/)


### 4.2 生成数据库变更文件

在项目根目录下执行如下命令：

```bash
python manage.py makemigrations yourappname
```

执行成功后就会生成数据库变更文件，文件位于新建 APP 的 migrations 目录中。


### 4.3 生效数据库变更

在项目根目录下执行如下命令：

```bash
python manage.py migrate yourappname
```

__注意__：在把 yourappname 加入 config/default.py 的 INSTALLED_APPS 中之前，请先执行 python manage.py migrate 初始化数据库。


## 5. 使用模板

开发框架支持 Django、 Mako 两种模板渲染引擎，在 Django 工程下每个 App 维护自身的模板文件，以下以 APP_NAME 代表 Django APP 名称。


### 5.1 Django 模板文件使用方式（这里不讨论具体的语法）

请将你的 Django 模板文件 xxx.html 放在 `PROJECT_ROOT/APP_NAME/templates/` 目录底下，建议在 templates 底下在加上一层目录，取名为 APP_NAME，即最终模板文件存放路径为 `PROJECT_ROOT/APP_NAME/templates/APP_NAME`，这是为了避免在寻找模板文件的时候，出现覆盖的情况。
使用 Django 原生支持的 render 方法进行模板渲染。

```python
from django.shortcuts import render

def index(request):
    return render(request, 'APP_NAME/index.html', {})
```

render 函数接受三个参数：
* 第一个参数 request对象。
* 第二个参数 模板路径，从 APP templates 目录开始写起，此处对应的完整路径为 PROJECT_ROOT/APP_NAME/templates/APP_NAME/index.html，注意不要在前面加 '/'，否则会被识别为绝对路径，找不到对应的模板。
* 第三个参数 传入的模板上下文，用于替换模板中的变量。

> 为什么 templates 目录底下还需要再加一层以 APP_NAME 命名的目录？
> 假设 settings INSTALLED_APPS = ('app1', 'app2')，工程目录如下
> ```
> PROJCET_ROOT
>   |__ app1
>   |__ __ templates
>   |__ __ __ index.html
>   ...
>   |__ app2
>   |__ __ templates
>   |__ __ __ index.html
> ```
>
> 当我们在 app2.views 里使用 `render(request, 'index.html', {})` 语句进行渲染时，Django 框架默认以 INSTALLED_APPS 安装次序进行模板文件查找，这时候会匹配到 `app1/templates/index.html` 文件进行渲染，导致得到非预期的结果。所以推荐  `PROJECT_ROOT/APP_NAME/templates/APP_NAME` 这样的目录设计
>


### 5.2  Mako 模板文件使用方式

Mako 模板文件使用方式大致与 Django 模板文件相同，唯一的区别就是是 Mako 模板文件放在 PROJECT_ROOT/APP_NAME/mako_templates/ 目录底下，同样建议在 mako 底下在加上一层目录，取名为 APP_NAME，最终模板文件存放路径为 PROJECT_ROOT/APP_NAME/mako_templates/APP_NAME。


### 5.3 Template-Context 平台框架提供的模板变量

这里列举的模板变量，不需要用户在 render 模板时传入，可直接在模板文件中访问到，直接使用。

```python
context = {
    'STATIC_URL': settings.STATIC_URL,                    # 本地静态文件访问
    'APP_PATH': request.get_full_path(),                  # 当前页面，主要为了login_required做跳转用
    'RUN_MODE': settings.RUN_MODE,                        # 运行模式
    'APP_CODE': settings.APP_CODE,                        # 在蓝鲸系统中注册的  "应用编码"
    'SITE_URL': settings.SITE_URL,                        # URL前缀
    'REMOTE_STATIC_URL': settings.REMOTE_STATIC_URL,      # 远程静态资源url
    'STATIC_VERSION': settings.STATIC_VERSION,            # 静态资源版本号,用于指示浏览器更新缓存
    'BK_URL': settings.BK_URL,                            # 蓝鲸平台URL
    'USERNAME': username,                                 # 用户名
    'NICKNAME': nickname,                                 # 用户昵称
    'AVATAR_URL': avatar_url,                             # 用户头像

    'WEIXIN_SITE_URL': settings.WEIXIN_SITE_URL,                   # WEIXIN ROOT URL
    'WEIXIN_STATIC_URL': settings.WEIXIN_STATIC_URL,               # WEIXIN 本地静态资源链接
    'WEIXIN_REMOTE_STATIC_URL': settings.WEIXIN_REMOTE_STATIC_URL  # WEIXIN 远程静态资源链接
}
```


## 6. 静态资源使用规范

- 静态文件按模块划分，分别放在 Django 工程中每个对应APP的 static 目录下
请将你的 Django 静态文件 xxx.js和xxx.css 放在 PROJECT_ROOT/APP_NAME/static/ 目录底下，建议在 static 底下在加上一层目录，取名为 APP_NAME，即最终模板文件存放路径为 PROJECT_ROOT/APP_NAME/static/APP_NAME[/js或者/css]，这是为了避免在寻找静态文件的时候，出现覆盖的情况。

- 修改静态文件后要手动运行 python manage.py collectstatic 命令来收集静态文件到根目录的static文件夹中。

- settings需要包含STATIC_ROOT配置。

```python
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
```

- 框架已配置全局有效的静态目录，可以将所有公共使用的静态资源放置于此。

```python
STATICFILES_DIRS = (
    os.path.join(BASE_DIR, 'static'),
)
```

其中 BASE_DIR 是工程根目录路径。


## 7. celery 使用


### 7.1 打开 Celery 配置

在 config/default.py 中修改配置：

```python
IS_USE_CELERY = True
```


### 7.2 添加 Celery 任务

在 app 底下创建 tasks.py 文件，添加 @task 任务：

```python
from celery import task

@task
def mul(x, y):
    return x * y
```

如果 @task 任务函数不在 app/tasks.py 文件中，需要在 config/default.py 中添加配置：

```python
CELERY_IMPORTS = (
    'testapp.tasks2'
)
```


### 7.3 启动异步任务服务 celery worker

在根目录执行：

```bash
python manage.py celery worker -l info
```


### 7.4 启动周期性任务服务 celery beat

在根目录执行：

```bash
python manage.py celery beat -l info 
```


### 7.5 添加周期任务

进入 admin，在 DJCELERY->Periodic_tasks 表中添加一条记录。


### 7.6 如何在平台部署时，自动启动 celery 进程

修改项目目录下的 Procfile 文件，添加以下两行命令：

```bash
worker: python manage.py celery worker -l info
beat: python manage.py celery beat -l info
```

不使用时，请修改 IS_USE_CELERY = True，并删除项目目录下的 Procfile 文件中 celery 配置

### 7.7 调整 celery worker 并发数

- CELERYD_CONCURRENCY 参数官方说明：

http://docs.celeryproject.org/en/v2.2.4/configuration.html#celeryd-prefetch-multiplier

- 目前开发框架设置的 celery 并发数是 2，如需调整，有 2 种方法：

1）在蓝鲸平台的 APP 环境变量新增 KEY 为 CELERYD_CONCURRENCY 的变量，并设置对应的值（调大前建议咨询平台维护同事）。
2）直接修改 APP 中的配置，即修改 /config/default.py 文件中如下配置的默认值 2 为你想要设置的值。

```python
CELERYD_CONCURRENCY = os.getenv('BK_CELERYD_CONCURRENCY', 2)
```


## 8. 日志使用

- 日志相关配置方式复用 Django 的配置方式

   https://docs.djangoproject.com/en/1.11/topics/logging/#using-logging

```python
import logging
logger = logging.getLogger('app')				# 普通日志
logger_celery = logging.getLogger('celery')		# celery日志
logger.error('log your info here.')

# 第二种方式
from blueapps.util.logger import logger         # 普通日志
from blueapps.util.logger import logger_celery  # celery日志
logger.error('log your info here.')
```

- 日志输出路径：

本地输出路径在和项目根目录平级的 logs 目录下。
``` 
- PROJCET_ROOT
- logs
    - APP_CODE
        - APP_CODE-celery.log
        - APP_CODE-component.log
        - APP_CODE-django.log
        - APP_CODE-mysql.log
```
 
- 日志级别配置：

日志级别默认是 INFO，如需修改，请在 config/default.py 或者 config/prod.py（只影响生产环境）、config/stag.py（只影响预发布环境）、config/dev.py（只影响预本地开发环境）中添加如下代码。

```python
import logging
logger = logging.getLogger('app')
logger.setsetLevel('DEBUG')
logger.setsetLevel('INFO')
logger.setsetLevel('WARNING')
logger.setsetLevel('ERROR')
logger.setsetLevel('CRITICAL')
logger_celery = logging.getLogger('celery')
logger_celery.setsetLevel('DEBUG')
logger_celery.setsetLevel('INFO')
logger_celery.setsetLevel('WARNING')
logger_celery.setsetLevel('ERROR')
logger_celery.setsetLevel('CRITICAL')
```


## 9. 异常处理

为了减少代码中判断函数调用的判断逻辑，蓝鲸开发框架提出，开发者应该在异常处直接抛出异常，通过 Django 中间件特性来处理该异常。


### 9.1 使用样例

```python
from blueapps.core.exceptions import ArgsMissing
def your_view_func(request):
	form = your_form(request.POST)
	if not form.is_valid():
		raise ArgsValidateFailed(u'参数验证失败,请确认后重试')
	# do something you  want
```

__注意__：此处只是一个简单的示例。我们强烈的建议开发者应该在任何有错误的地方直接抛出异常，而非返回错误，由上层逻辑处理。


### 9.2 异常类型介绍

蓝鲸开发框架异常类主要分为两类：客户端异常及服务端异常，分别对应由于客户端请求引起的错误和后台服务引起的错误。开发者可以根据引起错误的场景来选择需要抛出的异常。

- 异常类所在命名空间

blueapps.core.exceptions
       
       
- 服务端异常
  
    ||错误类||说明||http 状态码||返回错误码||场景举例
	||DatabaseError||数据库异常 || 501|| 50110||更新数据库记录失败
	||ApiNetworkError||网络异常导致远程服务失效||503||50301||请求第三方接口由于网络连接问题导致失败
	||ApiResultError||远程服务请求结果异常||503||50302||请求第三方结果返回result结果是false
	||ApiNotAcceptable||远程服务返回结果格式异常||503||50303||第三方接口返回xml格式结果，但预期返回json格式
       
- 客户端异常
   
    ||错误类||说明||http 状态码||返回错误码||场景举例
	||ResourceNotFound||找不到请求的资源 || 404|| 40400||找不到用户请求的某个指定ID的model
	||ArgsValidateFailed||参数验证失败||400||40000||期待为整形的参数，用户提供了一个字符参数
	||ArgsMissing||请求参数缺失||400||40001||期待的参数找不到
	||AccessForbidden||登陆失败||403||40301||用户身份验证失败
	||RequestForbidden||请求拒绝||403||40320||用户企图操作没有权限的任务
	||ResourceLock||请求资源被锁定||403||40330||用户企图操作一个已经锁定的任务
	||MethodError||请求方法不支持||405||40501||用户发送的请求不在预期范围内


# 三. 使用进阶


## 1. 登录模块


### 1.1 豁免登录

目前所有的 view 访问全部强制要求登录鉴权, 用户可以豁免一些 view 的登录限制，主要用于对外提供 API。

```python
from blueapps.account.decorators import login_exempt

@login_exempt
def myview(request):
    return "hello world"
```


## 2. User Model 获取 & 使用方式


### 2.1 获取 User Model

通过  `from blueapps.account import get_user_model` 可得到 User Model


### 2.2 User 方法属性说明

- username

用户唯一标识，在内部版为 RTX，在混合云为 QQ 号，在腾讯云为 openid

- nickname

用于前端展示的用户名，在内部版为 RTX，在混合云为 QQ 昵称，在腾讯云为 QQ 昵称

- avatar_url

用户头像 URL

- get_full_name

用于前端展示的完整用户名，在内部版为 rtx，在混合云为 昵称（QQ），腾讯云为 昵称

### 2.3 User 扩展属性说明

- get_property(key)

用户获取水平扩展属性

```python
from blueapps.account import get_user_model

user = get_user_model().objects.get(username=xxx)
user.get_property(key)
```

- set_property(key,value)

用户设置水平扩展属性

```python
from blueapps.account import get_user_model

user = get_user_model().objects.get(username=xxx)
user.set_property(key, value)
```

### 2.4 在模板中使用 User 作为外键

```python
from django.conf import settings
from django.db import models

class SomeModel(models.Model):
    person = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name=u"用户")
```

### 2.5 Django APP 管理员设置

修改 config/default.py 的 INIT_SUPERUSER 配置，填写用户名列表，默认值是应用创建人，列表中的人员将拥有预发布环境和正式环境的管理员权限。需要注意的是，该配置需要在首次提测和上线前修改，之后的修改将不会生效。
如果不小心将唯一的管理员权限去掉了，有两种方式新增管理员：

- 通过 migrations 实现

在你的 APP 目录下，找到 migrations 文件夹，新建文件 {INDEX}_init_superuser.py：

```python
# -*- coding: utf-8 -*-
from django.db import migrations
from django.conf import settings


def load_data(apps, schema_editor):
    """
    添加用户为管理员
    """
    User = apps.get_model("account", "User")
    for name in settings.INIT_SUPERUSER:
        User.objects.update_or_create(
            username=name,
            defaults={'is_staff': True, 'is_active': True, 'is_superuser': True}
        )


class Migration(migrations.Migration):
    dependencies = [
        ('{APP}', '{APP_LAST_MIGRATION}')
    ]
    operations = [
        migrations.RunPython(load_data)
    ]
```

其中，{APP} 表示你的当前 APP，{APP_LAST_MIGRATION} 表示当前 mirgations 文件中最新一个文件名（如 “0003_auto_20180301_1732”），{INDEX} 表示最新一个文件名的前缀数字加1（如 “0003_auto_20180301_1732” 的前缀数字是 “0003”，那么 {INDEX} 设置为 “0004”）。

- 通过 views 实现

在你的 APP 目录的 views 文件中，添加如下代码：

```python
from django.conf import settings
from django.http import HttpResponse

from blueapps.account import get_user_model


def load_data(request):
    """
    添加用户为管理员
    """
    User = get_user_model()
    for name in settings.INIT_SUPERUSER:
        User.objects.update_or_create(
            username=name,
            defaults={'is_staff': True, 'is_active': True, 'is_superuser': True}
        )
    return HttpResponse('Success')
```

然后配置一条 URL 路由规则到该 view，提测、上线后访问对应 URL 就可以初始化管理员了。


## 3. 移动端开发配置

【蓝鲸PaaS平台移动版应用开发指南】

### 3.1 URL 配置规范

所有要在移动端访问的 URL 都需要以 `weixin/` 作为前缀路径，如 `url('^weixin/xxx/$', 'xxx' )`，可在 `urls.py` 中配置以 `weixin/` 为前缀的 URL。

### 3.2 View 编写规范

View 函数的编写与 PC 端的代码编写没区别，在登录逻辑上，最新的开发框架已经在登录中间件里集成了。

__注意__：本地开发移动端登录上是使用 OA 登录，在 PC 端访问应用的正式和测试环境是使用统一登录，在移动端（微信腾讯企业号蓝鲸助手）访问应用的正式和测试环境是使用微信登录。

### 3.3 Template 编写规范

在移动端的 Template 页面中，可以使用 `WEIXIN_STATIC_URL`、`WEIXIN_REMOTE_STATIC_URL`、`WEIXIN_SITE_URL` 来获取移动端的本地静态规范文件路径前缀、远程静态规范文件路径前缀、APP 访问 URL 前缀，这与 PC 端开发时的 `STATIC_URL`、`REMOTE_STATIC_URL`、`SITE_URL` 作用类似。

__注意__：`<script src="${WEIXIN_STATIC_URL}js/settings.js"></script>` 请不要删除，必须引用 settings.js，否则前端 POST 请求将出现 CSRFTOKEN 错误问题。

### 3.4 静态资源使用规范

- 本地静态资源
必须放置在``static/weixin/`` 下。

- 远程静态资源
蓝鲸平台为开发者提供了【移动版开发样例】，开发者可参考移动版前端页面样例进行开发，其中如果使用到远程静态资源，请将文件前缀替换为 `${WEIXIN_REMOTE_STATIC_URL}`。


## 4. 配置修改指引


### 4.1 settings 主要配置

__注意__：不要修改 settings.py ，配置项修改请在 config 目录下的文件中进行。

其中，如果修改 config/default.py 配置项对所有的运行环境生效（正式环境、预发布环境、本地环境）；
修改 config/prod.py 配置项只会对正式环境生效；
修改 config/stag.py 配置项只会对预发布环境生效；
修改 config/dev.py 配置项只会对本地开发环境生效；
在多人开发时，为了避免 config/dev.py 中的配置互相影响，每个开发者都可以在项目根目录下新增 local_settings.py 文件，来添加各开发者不同的本地开发配置，如 DATABASES，并在提交代码时忽略 local_settings.py 文件。
    
- 自定义 Django APP

请修改 config/default.py 的 INSTALLED_APPS
	
- 自定义中间件

请修改 config/default.py 的 MIDDLEWARE
	
- 自定义数据库

如无必要请不要覆盖默认 default 数据库，正式环境和预发布环境分别修改 config/prod.py 和 config/stag.py，使用 DATABASES.update() 方法。
本地环境请修改 config/dev.py 的 DATABASES。

- 自定义日志级别

日志级别默认是 INFO，如需修改，请在 config/default.py 或者 config/prod.py（只影响生产环境）、config/stag.py（只影响预发布环境）、config/dev.py（只影响预本地开发环境）中添加如下代码。

```python
import logging
logger = logging.getLogger('app')
logger.setsetLevel('DEBUG')
logger.setsetLevel('INFO')
logger.setsetLevel('WARNING')
logger.setsetLevel('ERROR')
logger.setsetLevel('CRITICAL')
logger_celery = logging.getLogger('celery')
logger_celery.setsetLevel('DEBUG')
logger_celery.setsetLevel('INFO')
logger_celery.setsetLevel('WARNING')
logger_celery.setsetLevel('ERROR')
logger_celery.setsetLevel('CRITICAL')
```

其中，不同配置的含义如下：
DEBUG：用于调试目的的底层系统信息
INFO：普通的系统信息
WARNING：表示出现一个较小的问题。
ERROR：表示出现一个较大的问题。
CRITICAL：表示出现一个致命的问题。

- 静态资源版本号更新

修改 config/default.py 的 STATIC_VERSION。

- 添加 celery 任务

把 celery 任务模块加入 config/default.py 的 CELERY_IMPORTS。

- 初始化管理员列表

请修改 config/default.py 的 INIT_SUPERUSER，列表中的人员将拥有预发布环境和正式环境的管理员权限。请在首次提测和上线前修改，之后的修改将不会生效。

-  自定义其他 Django 支持的配置

请直接在 config/default.py 添加需要的配置覆盖默认值。


### 4.2 使用 settings 配置

在Django 应用中，可以通过导入django.conf.settings 对象来使用设置。例如：

```python
from django.conf import settings

if settings.DEBUG:
    # Do something
```

__注意__：django.conf.settings 不是一个模块 —— 它是一个对象。所以不可以导入每个单独的设置

```python
from django.conf.settings import DEBUG  # This won't work.
```

__注意__：你的代码不应该从 config.default.py 或其他设置文件中导入。django.conf.settings 抽象出默认设置和站点特定设置的概念；它表示一个单一的接口。它还可以将代码从你的设置所在的位置解耦出来。


## 5. 安全相关 csrf / xss等
TODO


## 6. 自定义middleware(中间件)

- default.py 配置如下

```python
MIDDLEWARE += (
# 你的中间件
)
```

__注意__：django1.10 开始，中间件配置项使用 __`MIDDLEWARE`__ ，1.10 以下版本使用的 MIDDLEWARE_CLASSES 配置项会在 django2.0 后不再被支持。

- midlleware开发

使用MIDDLEWARE配置项开发你的middleware。

```python
from django.utils.deprecation import MiddlewareMixin

class MyCustomMiddleware(MiddlewareMixin):
	# 中间件支持的方法依然不变
	def process_request(request):
		...
	def process_view(request, callback, callback_args, callback_kwargs):
		...
	def process_template_response(request, response):
		...
	def process_response(request, response):
		...
	def process_exception(request, exception):
		...
```

__注意__： 你的 middleware 类必须继承 django 的 MiddlewareMixin，同时你的 middleware 尽量不要去重写 `__call__` 和 `__init__` 方法，参考[官方文档](https://docs.djangoproject.com/en/1.11/topics/http/middleware/)。


## 7. decorator(装饰器)

- 登录豁免装饰器

```python
from blueapps.account.decorators import login_exempt

@login_exempt
def myview(request):
    return "hello world"
```

- 自定义装饰器

本质上，decorator 就是一个返回函数的高阶函数。所以，我们要定义一个能打印日志的 decorator，可以定义如下：

```python
def log(func):
    def wrapper(*args, **kw):
        print ('call {name}():'.format(name=func.__name__))
        return func(*args, **kw)
    return wrapper
    
    
# use
@log
def test(arg):
    pass
```

如果 decorator 本身需要传入参数，那就需要编写一个返回 decorator 的高阶函数，写出来会更复杂。比如，要自定义日志的文本：

```python
def log(text):
    def decorator(func):
        def wrapper(*args, **kw):
            print ('{text} {name}():'.format(text=text, name=func.__name__))
            return func(*args, **kw)
        return wrapper
    return decorator
    
    
# use
@log('this is text')
def test(arg):
    pass
```


## 8. 公共方法


### 8.1 blueapps.utils.esbclient
TODO

### 8.2 blueapps.utils.logger
提供常用的logger,logger_celery
```python
from blueapps.util.logger import logger         # 普通日志
from blueapps.util.logger import logger_celery  # celery日志
logger.error('log your info here.')
```


## 9. restful支持


## 10. 新老框架差异

- render_json

请选择 Django 提供 JsonResponse 进行替换

```python
from django.http import JsonResponse

def index(requset):
    data = {}
    return JsonResponse(data)
```

- render_mako_context

请使用 django.shortcut.render 方法替代

```python
from django.shortcuts import render

def test_render(request):
    """
    模板文件渲染成页面
    """
    context = {'xxx': 111}
    return render(request, 'tmp/test_render.html', context)
```

- render_mako_tostring

请使用 django.template.loader.render_to_string 方法替代

```python
from django.template.loader import render_to_string

context = {'xxx': 111}
print (render_to_string('tmp/test_to_string.html', context))
```

- render_mako_tostring_context

请使用 django.template.loader.render_to_string 方法替代

```python
from django.template.loader import render_to_string

def test_render_to_string_with_request(request):
    """
    模板文件渲染成字符串
    """
    context = {'xxx': 1111}
    html = render_to_string('tmp/test_to_string.html', context, request=request)
    return JsonResponse({'reuslt': True, 'data': html})
```


# 四. 开发样例


## 1. 生成 PC 端样例

在安装了 blueapps SDK 后，开发框架支持以命令行的方式生成开发样例，在项目根目录下执行：

```bash
bk-admin startexample
```

__注意__：执行上述命令会在项目中生成 bluapps_example 模板和 APP 目录，覆盖 urls.py 文件，也会把样例依赖的 SDK 包追加到 requirements.txt。

如果想完整体验开发样例功能，请用 pip 安装依赖的 python 包，执行：

```bash
pip install -r requirements.txt
```

开发样例中包含了数据库变更，请在根目录下执行：

```bash
python manage.py migrate
```

如果想体验查询类样例，请先在“开发者中心-基本设置-云API权限”申请 APP 访问配置平台（CC）的get_query_info接口权限。


## 2. PC 端样例内容


### 2.1 首页

样例首页列举了开发框架提供的基础功能和说明引导。对应的代码模块是：

```
- 项目根目录
	- home_application
	- mako_application
```


### 2.2 功能样例

功能样例包含功能开关样例和短信验证码二步验证样例。

功能开关样例可以用来参考实现控制 APP 内某个功能是否开启的功能。当打开功能开关时，功能可以正常使用；关闭功能开关时，功能不能使用，并提示用户功能已关闭。选择功能开关后点击运行即有响应交互。

短信验证码二步验证样例可给登陆用户发送短信验证码，并对验证码进行校验，提示对应验证信息。

```
- 项目根目录
    - blueapps_example
        - app_control
```

__注意__：短信验证码二步验证样例内部版可直接使用，open版还需实现相应的接口才可使用。


### 2.3 后台任务样例

后台任务样例是使用 celery 执行后台任务的样例，包括定时任务和周期任务，对应的代码模块是：

```
- 项目根目录
    - blueapps_example
	    - test_celery
```

celery 是一个简单、灵活且可靠的，处理大量消息的分布式系统。蓝鲸应用可以基于 celery 实现后台任务执行和管理的功能。官方网站请参考 http://docs.celeryproject.org/en/master/index.html。


### 2.4 组件样例

组件样例包含了 ESB  组件查询示例，目前是以 CC 业务信息列表查询为例，用户可以看到业务信息列表的分页查询结果。组件样例对应的代码模块是：

```
- 项目根目录
    - blueapps_example
        - test_component
```

__注意__：使用这个功能前，请先在“开发者中心-基本设置-云API权限”申请 APP 访问配置平台（CC）的 get_app_list 接口权限。


### 2.5 ajax异步请求样例

ajax异步请求样例样例是使用 ajax 技术在前端实现对后端的异步请求和局部加载刷新，是前后端数据请求加载的主流方式，对应的代码模块是：

```
- 项目根目录
    - blueapps_example
        - test_app_tags
```


## 3. 生成移动端样例

在安装了 blueapps SDK 后，开发框架支持以命令行的方式生成移动端开发样例，在项目根目录下执行：

```bash
bk-admin startweixin
```

__注意__：执行上述命令会在项目中生成 weixin 模板和 APP 目录，覆盖 urls.py 文件。

如果想体验业务数据样例，


## 4. 移动端样例内容


### 4.1 图表样例

图表样例以柱状图,折线图和饼图展示了用户负责的业务。

__注意__：使用这个功能前，请先在“开发者中心-基本设置-云API权限”申请 APP 访问配置平台（CC）的 get_app_list_by_name 接口权限。

### 4.2 微信分享样例

微信分享样例使用微信 js-sdk 提供了一个分享朋友圈或朋友的功能。

