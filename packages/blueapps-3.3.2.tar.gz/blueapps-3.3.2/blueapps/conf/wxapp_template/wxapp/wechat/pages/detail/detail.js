const app = getApp()
Page({
    data: {
        id: '',
        paperDetails: {},
        tipMsg: '',
        isIphoneX: false,
        containerHeight: 350,
        isLoading: false,
        url: '',
        type: '',
        value: '',
        isFocus: false
    },

    onShow() {
        const that = this
    },

    onLoad(options) {
        this.setData({
            isIphoneX: app.globalData.isIphoneX ? app.globalData.isIphoneX : false,
            hasNoMore: false
        })
        this.setData({
            id: options.id
        })
        this.getPaperDetail()
    },

    getPaperDetail() {
        wx.showLoading({
            title: '数据加载中'
        })
        this.setData({
            isLoading: false
        })
        app.request({
            url: `/detail/${this.data.id}/`,
            success: (res) => {
                if (res.statusCode == 200 && res.data && res.data.result) {
                    this.setData({
                        paperDetails: res.data.data
                    })
                } else {
                    wx.showToast({
                        title: '系统错误',
                        icon: 'none',
                        mask: true
                    })
                }
            },
            complete: () => {
                wx.hideLoading()
                this.setData({
                    isLoading: true
                })
            }
        })
    }
})
