const configs = require('../config.js')

const bk = {
    globalData: {
        debug: configs.DEBUG,
        smartGateSession_Expire_Time: 600000,
        smartGateSession: null,
        smartGatePrefixed: configs.RIO_URL,
        smartGateApp: configs.RIO_APP,
        avatarUrl: '',
        wxkey: ''
    },

    //登陆鉴权
    authorize: function (cb) {
        const that = this;
        let _identity = wx.getStorageSync('__identity');
        if (!_identity) {
            _identity = "{}"
        }

        //超过设置的过期时间，则重新读取wx_key
        if (Date.now() < JSON.parse(_identity).expire_time) {
            typeof cb == "function" && cb(JSON.parse(_identity));
        } else {
            wx.login({
                success: function (res) {
                    if (res.code) {
                        wx.request({
                            url: `${that.globalData.smartGatePrefixed}/__code2key/?code=${res.code}&app=${that.globalData.smartGateApp}`,
                            header: {
                                'content-type': 'application/json'
                            },
                            success: function (data) {
                                const identity = data.data;

                                identity.expire_time = Date.now() + that.globalData.smartGateSession_Expire_Time;
                                wx.setStorageSync('__identity', JSON.stringify(identity));
                                that.globalData.smartGateSession = identity;
                                typeof cb == "function" && cb(identity);
                            },
                            fail: function (err) {
                                console.log(err);
                            }
                        });
                    }
                },
                fail: function () {
                    // fail
                    console.log(`fail:${res}`);
                },
                complete: function () {
                    // complete
                }
            });
        }
    },

    //请求数据
    request: function (param) {
        var that = this;
        that.authorize(function (res) {
            const p = getCurrentPages()
            const route = p.pop().__route__
            if (!res.staffID && route !== 'pages/no-permission/no-permission') {
                wx.reLaunch({
                    url: '../no-permission/no-permission'
                });
            }
            that.globalData.wxkey = res.key
            param.header = {
                wxappkey: res.key,
                csrftoken: res.csrf_token
            }
            param.url = that.getBkUrl(param.url);
            wx.request(param)
        })
    },

    //获取RIO转换的URL
    getBkUrl: function (url) {
        return `${this.globalData.smartGatePrefixed}/an:${configs.RIO_APP}${configs.BK_PATH}${url}`;
    }
};

module.exports = bk
