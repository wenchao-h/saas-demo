# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from weixin.core.base import API


class WeiXinApi(API):
    def __init__(self):
        super(WeiXinApi, self).__init__()

    # 主要用于微信JS-SDK，(具体使用：http://qydev.weixin.qq.com/wiki/index.php?title=%E5%BE%AE%E4%BF%A1JS-SDK%E6%8E%A5%E5%8F%A3)
    def get_js_sign(self, url, request_method="GET"):
        """
        获取微信JS签名信息
        url: 需要在页面上使用js签名对应的页面url, 一般直接request.build_absolute_uri()可以获取到
        request_method：请求的方式（GET, POST）一般直接request.method 可以获取到
        return:{
        'result': , 'message': ,
        'data': {'appId': , 'nonceStr': ,'signature': , 'timestamp': , 'url': }
        }
        """
        query_param = {
            "app_code": self.app_code,
            "Nonce": self.nonce_num(6),
            "Timestamp": self.timestamp,
            "url": url,
        }
        signature = self.gen_signature(
            query_param, self._config.WEIXIN_GET_JS_SIGN_PATH, request_method
        )
        query_param["Signature"] = signature
        data = self.http_get(self._config.WEIXIN_GET_JS_SIGN_URL, **query_param)
        return data
