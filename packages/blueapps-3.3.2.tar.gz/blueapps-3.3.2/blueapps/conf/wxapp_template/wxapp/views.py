# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

import copy
import logging

from django.http import JsonResponse
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger("app")


def index(request):
    """
    @summary: 显示文章列表
    """
    category_id = int(request.GET.get("category_id", 0))
    page = int(request.GET.get("page", 1))
    page_size = int(request.GET.get("page_size", 10))

    data = get_list(category_id, page, page_size)
    data["task_num"] = 5

    ret = {"result": True, "data": data}
    return JsonResponse(ret)


def detail(request, article_id):
    """
    @summary: 显示文章详情
    """
    id = int(article_id)
    data = get_data()

    result = {}
    for item in data:
        if item["id"] == id:
            result = item

    ret = {"result": True, "data": result}
    return JsonResponse(ret)


def category(request):
    ret = {
        "result": True,
        "data": [
            {"id": 1, "name": _(u"分类一")},
            {"id": 2, "name": _(u"分类二")},
            {"id": 3, "name": _(u"分类三")},
        ],
    }
    return JsonResponse(ret)


def get_list(category_id, page=1, page_size=5):
    data = get_data()

    # filter category
    list = []
    for item in data:
        if category_id:
            if item["category_id"] == category_id:
                list.append(item)
        else:
            list.append(item)

    # page
    total = len(list)
    start = (page - 1) * page_size
    offset = start + page_size

    result = []
    if start <= total:
        result = list[start:offset]

    ret = {"total": len(list), "list": result, "page": page, "page_size": page_size}
    return ret


def get_data():
    """
    获取文章列表
    """
    item = {
        "id": None,
        "category_id": 1,
        "title": _(u"第%s篇文章标题"),
        "content": _("这是内容%s"),
        "insert_at": u"2018-10-10 10:00:00",
        "insert_by": "user",
    }

    list = []
    for i in range(1, 21):
        row = copy.deepcopy(item)
        row["id"] = i
        row["category_id"] = i % 3 + 1
        row["title"] = row["title"] % i
        row["content"] = row["content"] % i
        list.append(row)
    return list
